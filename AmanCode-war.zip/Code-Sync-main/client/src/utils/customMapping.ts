const customMapping: { [key: string]: string } = {
    php: "php",
    cs: "csharp",
    // Maybe add more languages here
}

export default customMapping
